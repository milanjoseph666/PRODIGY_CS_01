def encrypt(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            result += chr((ord(char) - base + shift) % 26 + base)
        else:
            result += char
    return result

def decrypt(text, shift):
    return encrypt(text, -shift)

if __name__ == "__main__":
    choice = input("Choose an option (encrypt/decrypt): ").strip().lower()
    message = input("Enter your message: ")
    shift = int(input("Enter shift value: "))

    if choice == "encrypt":
        print("Encrypted message:", encrypt(message, shift))
    elif choice == "decrypt":
        print("Decrypted message:", decrypt(message, shift))
    else:
        print("Invalid option.")