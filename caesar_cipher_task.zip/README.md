# Caesar Cipher Task

This Python script allows encryption and decryption using the Caesar Cipher algorithm.

## Features
- Encrypt a message using a shift value.
- Decrypt a message using the same shift value.

## Usage

1. Run the script:
   python caesar_cipher.py

2. Choose to `encrypt` or `decrypt`.
3. Enter the message and shift value.

## Example
```
Choose an option (encrypt/decrypt): encrypt
Enter your message: Hello
Enter shift value: 3
Encrypted message: Khoor
```